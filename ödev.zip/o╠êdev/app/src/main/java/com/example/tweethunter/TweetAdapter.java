package com.example.tweethunter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TweetAdapter extends RecyclerView.Adapter<TweetAdapter.TweetViewHolder> {

    private List<Tweet> tweets;

    public TweetAdapter(FragmentActivity activity, List<Tweet> tweets) {
        this.tweets = tweets;
    }


    @Override
    public TweetViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.tweet_item, parent, false);
        return new TweetViewHolder(view);
    }

    @Override
    public void onBindViewHolder(TweetViewHolder holder, int position) {
        Tweet tweet = tweets.get(position);
        holder.bind(tweet);
    }

    @Override
    public int getItemCount() {
        return tweets.size();
    }

    public static class TweetViewHolder extends RecyclerView.ViewHolder {

        private TextView usernameTextView;
        private TextView tweetTextView;
        private ImageView tweetImageView;

        public TweetViewHolder(View itemView) {
            super(itemView);
            usernameTextView = itemView.findViewById(R.id.username_text_view);
            tweetTextView = itemView.findViewById(R.id.tweet_text_view);
            tweetImageView = itemView.findViewById(R.id.tweet_image_view);
        }

        public void bind(Tweet tweet) {
            usernameTextView.setText(tweet.getUsername());
            tweetTextView.setText(tweet.getTweetText());
            tweetImageView.setVisibility(View.GONE);

        }
    }
}
