package com.example.tweethunter;



public class Tweet {
    private String username;
    private String tweetText;

    public Tweet(String username, String tweetText) {
        this.username = username;
        this.tweetText = tweetText;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getTweetText() {
        return tweetText;
    }

    public void setTweetText(String tweetText) {
        this.tweetText = tweetText;
    }
}
