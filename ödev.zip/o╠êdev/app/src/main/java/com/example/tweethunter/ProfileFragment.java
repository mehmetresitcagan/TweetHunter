package com.example.tweethunter;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ProfileFragment extends Fragment {

    private RecyclerView tweetsRecyclerView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_profile, container, false);

        // Find the RecyclerView
        tweetsRecyclerView = rootView.findViewById(R.id.tweets_recycler_view);

        // Set up the RecyclerView
        tweetsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Fetch the tweets data and set the adapter for the RecyclerView
        List<Tweet> tweets = fetchTweets();
        TweetAdapter adapter = new TweetAdapter(getActivity(), tweets);
        tweetsRecyclerView.setAdapter(adapter);

        return rootView;
    }

    private List<Tweet> fetchTweets() {
        // TODO: Fetch the tweets data from the Twitter API or local database
        return new ArrayList<>();
    }
}

